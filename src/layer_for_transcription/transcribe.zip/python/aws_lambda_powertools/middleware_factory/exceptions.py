class MiddlewareInvalidArgumentError(Exception):
    """When middleware receives non keyword=arguments"""
