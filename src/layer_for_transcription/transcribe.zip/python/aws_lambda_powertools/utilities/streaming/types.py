from typing import IO, TypeVar

T = TypeVar("T", bound=IO[bytes])
